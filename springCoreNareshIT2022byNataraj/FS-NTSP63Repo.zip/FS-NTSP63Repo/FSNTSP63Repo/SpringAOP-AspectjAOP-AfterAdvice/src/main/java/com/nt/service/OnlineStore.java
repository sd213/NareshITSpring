//OnlineStore.java
package com.nt.service;

import org.springframework.stereotype.Component;

@Component("ostore")
public class OnlineStore {
	
	public   double  shopping(String items[], double prices[]) {
		//caculate the bill amount
		 double billAmt=0.0f;
		 for(double p:prices) {
			 billAmt+=p;
		 }
		 return   billAmt;
	}

}
