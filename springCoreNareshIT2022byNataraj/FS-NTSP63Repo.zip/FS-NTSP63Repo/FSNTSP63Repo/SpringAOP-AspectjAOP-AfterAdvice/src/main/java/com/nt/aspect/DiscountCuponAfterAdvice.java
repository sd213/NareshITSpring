//DiscountCuponAfterAdvice .java
package com.nt.aspect;

import java.io.FileWriter;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component("cuponAdvice")
public class DiscountCuponAfterAdvice {
	
	
	@AfterReturning(value="execution( double  com.nt.service.OnlineStore.shopping(..))",returning ="billAmt" )
	public   void  cuponGeneration(JoinPoint jp, double  billAmt)throws Throwable {
		//CuponMessage generation logic
		String cuponMsg=null;
		if(billAmt>=50000)
			 cuponMsg="Avail 30% on next purchase";
		else if(billAmt>=40000)
			 cuponMsg="Avail 20% on next purchase";
		else if(billAmt>=30000)
			 cuponMsg="Avail 10% on next purchase";
		else
			 cuponMsg="Avail 5% on next purchase";
		//write  cupon Message to file
		FileWriter writer=new FileWriter("cupon.txt");
		writer.write(cuponMsg);
		writer.flush();
		writer.close();
		
	}

}
