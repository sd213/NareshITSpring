package com.nt.service;

public interface IWishMessageService {
     public  String generateWishMessage();
}
