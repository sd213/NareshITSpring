//InvalidInputsException.java  (user-defined Exception)
package com.nt.exception;

public class InvalidInputsException extends Exception {
	
	public InvalidInputsException(String msg) {
		super(msg);
	}

}
