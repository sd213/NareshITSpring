//CommonExceptionLogger_Grapher.java  (Aspect class)
package com.nt.aspect;

import java.io.FileWriter;
import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.nt.exception.InvalidInputsException;

@Component("expLogger_grapher")
@Aspect
public class CommonExceptionLogger_Grapher {
	
	@AfterThrowing(value="execution(double  com.nt.service.ShoppingStore.shopping(..))",throwing = "iae")
	public   void  exceptionLogger_Grapher(JoinPoint jp,IllegalAccessException iae) throws Throwable{
		// common Exception Logger logic
		FileWriter writer=new FileWriter("exception_log.txt",true);
		writer.write("\n"+iae+" exception is raised in"+jp.getSignature()+" method with arg values "+Arrays.deepToString(jp.getArgs()));
		writer.flush();
		writer.close();
		//common Exception grapher  (Translating one from of the exception to another form of the exception)
		throw new InvalidInputsException(iae.getMessage());  //exception rethrowing concept is used
		
		
	}

}
