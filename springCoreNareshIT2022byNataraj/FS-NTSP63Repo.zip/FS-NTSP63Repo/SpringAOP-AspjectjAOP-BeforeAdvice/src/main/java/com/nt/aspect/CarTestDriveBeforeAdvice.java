//CarTestDriveBeforeAdvice.java
package com.nt.aspect;


import java.util.Scanner;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component("testDrive")
@Aspect
public class CarTestDriveBeforeAdvice {
	
	@Before("execution(java.lang.String com.nt.service.CarShowRoom.purchaseCar(..))")
	public void   testDrive(JoinPoint jp)throws Throwable{
		System.out.println("CarTestDriveBeforeAdvice.testDrive()");
		Object args[]=jp.getArgs();
		System.out.println(args[0]+" Model car has come for test driving");
		Scanner  sc=new Scanner(System.in);
		System.out.println("Enter  did u like the car?(true/false)");
		boolean flag=sc.nextBoolean();
		 if(!flag)
			 throw new IllegalAccessException("Car Model is not liked");
	}
	

}
