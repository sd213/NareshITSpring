//BeforeAdvice.java
package com.nt.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.service.CarShowRoom;

public class BeforeAdviceTest {

	public static void main(String[] args) {
		//create IOC container
		 ClassPathXmlApplicationContext ctx=
				  new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		 //get Proxy class object
		 CarShowRoom  proxy=ctx.getBean("showRoom",CarShowRoom.class);
		 //invoke the b.method
		 try {
			 String result=proxy.purchaseCar("Mahindra-XUV700",3200000.0 , 12.0);
			 System.out.println(result);
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
        //close the container 
		 ctx.close();
	}

}
