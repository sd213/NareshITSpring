//CarShowRoom.java
package com.nt.service;

import org.springframework.stereotype.Service;

@Service("showRoom")
public class CarShowRoom {
	
	public   String  purchaseCar(String modelName, double price , double discountPercentage) {
		System.out.println("CarShowRoom.purchaseCar()");
		  double finalPrice= price-(price*discountPercentage/100.0f);
		  return   modelName+"  Car is purchased at the price of"+finalPrice;
	}

}
