//IStudentService.java
package com.nt.service;

import com.nt.model.Student;

public interface IStudentService {
    public String registerStudent(Student stud);
}
