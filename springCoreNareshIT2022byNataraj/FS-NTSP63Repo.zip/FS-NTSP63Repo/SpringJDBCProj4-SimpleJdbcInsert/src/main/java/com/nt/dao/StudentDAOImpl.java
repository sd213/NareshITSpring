//tudentDAOImpl.java
package com.nt.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.nt.model.Student;

@Repository("studDAO")
public class StudentDAOImpl implements IStudentDAO {
	@Autowired
	private  SimpleJdbcInsert sji;

	/*@Override
	public int insert(Student stud) {
		//set db table name
		sji.setTableName("STUDENT");
		// prepare Map collection having  col names and col values
		Map<String,Object> paramMap=new HashMap();
		paramMap.put("sno", stud.getSno());
		paramMap.put("sname",stud.getSname());
		paramMap.put("sadd",stud.getSadd());
		paramMap.put("avg",stud.getAvg());
		//generate and exeucte the INSERT SQL Query dynamically
		int count=sji.execute(paramMap);
		return count;
	}*/
	
	/*	@Override
		public int insert(Student stud) {
			//set db table name
			sji.setTableName("STUDENT");
			// prepare MapSqlParameterSource  having col names and values
			  MapSqlParameterSource source=new MapSqlParameterSource();
			  source.addValue("sno", stud.getSno());
			  source.addValue("sname", stud.getSname());
			  source.addValue("sadd", stud.getSadd());
			  source.addValue("avg", stud.getAvg());
			//generate and exeucte the INSERT SQL Query dynamically
			int count=sji.execute(source);
			return count;
		}*/
	
	
	@Override
	public int insert(Student stud) {
		//set db table name
		sji.setTableName("STUDENT");
		// prepare BeanPropertySqlParameterSource   having model class obj
		  BeanPropertySqlParameterSource  source=new BeanPropertySqlParameterSource(stud);
		//generate and exeucte the INSERT SQL Query dynamically
		int count=sji.execute(source);
		return count;
	}

}
