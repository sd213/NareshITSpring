//Client App
package com.nt.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.Student;
import com.nt.service.IStudentService;

public class SimpleJdbcInsertTest {

	public static void main(String[] args) {
		  //create IOC container
		 ClassPathXmlApplicationContext ctx=
				  new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		 //get Service class obj ref
		 IStudentService  service=ctx.getBean("studService",IStudentService.class);
		 //invoke the method
		   Student st=new Student();
		   st.setSno(1045); st.setSname("raveesh"); st.setSadd("secBad"); st.setAvg(67.99f);
		   String msg=service.registerStudent(st);
		   System.out.println(msg);
		   
		   // close the container
		   ctx.close();
				 
	}

}
