// IStudentDAO.java
package com.nt.dao;

import com.nt.model.Student;

public interface IStudentDAO {
	
	public  int  insert(Student stud);

}
