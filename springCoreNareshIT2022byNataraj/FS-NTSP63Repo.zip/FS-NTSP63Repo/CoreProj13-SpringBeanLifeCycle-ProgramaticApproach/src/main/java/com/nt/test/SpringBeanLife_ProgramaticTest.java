package com.nt.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.sbeans.VotingElgibilityCheckService;

public class SpringBeanLife_ProgramaticTest {

	public static void main(String[] args) {
		//create IOC container
		 ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		 // get Spring Bean class object from IOC container
		 VotingElgibilityCheckService service=ctx.getBean("voter",VotingElgibilityCheckService.class);
		 //invoke the b.method
		 String result=service.checkVotingElgibility();
		 System.out.println(result);
		 
		 //close container
		 ctx.close();

	}

}
