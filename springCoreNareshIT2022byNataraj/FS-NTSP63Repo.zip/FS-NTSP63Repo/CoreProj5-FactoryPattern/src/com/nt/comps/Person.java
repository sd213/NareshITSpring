//Person.java
package com.nt.comps;

public interface Person {
     public void doTask();
}
