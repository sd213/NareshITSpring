//Client app
package com.nt.test;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.Employee;
import com.nt.service.IEmployeeMgmtService;

public class JdbcTemplate_CallbackInterfacesTest {

	public static void main(String[] args) {
		//create IOC container
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		//get Service class obj
		IEmployeeMgmtService service=ctx.getBean("empService",IEmployeeMgmtService.class);
		//invoke the method
		Employee emp=service.showEmpDetailsByNo(7499);
		System.out.println("7499 emp details ::"+emp);
		System.out.println("==================================");
		
		List<Employee> list=service.fetchEmployeeDetailsByDesg("CLERK");
		list.forEach(e->{
			System.out.println(e);
		});
		
		//close contianer
		ctx.close();

	}

}
