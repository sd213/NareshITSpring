//Courier.java (Common Interface)
package com.nt.comps;

public interface Courier {
    public   String  deliver(int oid);
}
