//LoginDAOImpl.java
package com.nt.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

/*create or replace procedure  Auth_pro(user in varchar2, pass in varchar2, result out varchar2)
as
  cnt number(4);
begin
   select count(*) into cnt from usersinfo where  uname=user and pwd=pass;
   if(cnt<>0) then
         result:='ValidCredentials';
   else
         result:='InValidCredentials';
  end if;
end;
/
*/
@Repository("loginDAO")
public class LoginDAOImpl implements ILoginDAO {
	@Autowired
	private SimpleJdbcCall  sjc;

	@Override
	public String authenticate(String username, String password) {
		 //set Procedure name
	     sjc.setProcedureName("AUTH_PRO");
	     // prepare Map object having In param names and values
	     Map<String,Object> inParams=new HashMap();
	     inParams.put("user", username);
	     inParams.put("pass",password);
	     // call PL/SQL procedure
	      Map<String,Object> outParams=sjc.execute(inParams);
	     //gather result
	      String result=(String)outParams.get("RESULT");
		return result;
	}

}
