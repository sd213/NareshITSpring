//SimpleJdbcCallTest.java
package com.nt.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.service.ILoginMgmtService;

public class SimpleJdbcCallTest {

	public static void main(String[] args) {
		 //create IOC contianer
		 ClassPathXmlApplicationContext ctx=
				   new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		 //get Service class obj
		 ILoginMgmtService service=ctx.getBean("loginService",ILoginMgmtService.class);
		 //invoke the b.method
		 String result=service.singnIn("raja", "rani1");
		 System.out.println(result);
		 
		 //close container
		 ctx.close();

	}

}
