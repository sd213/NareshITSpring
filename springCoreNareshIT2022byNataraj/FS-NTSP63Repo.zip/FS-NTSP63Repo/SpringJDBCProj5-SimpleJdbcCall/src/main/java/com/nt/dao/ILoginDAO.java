//ILoginDAO.java
package com.nt.dao;

public interface ILoginDAO {
        public  String authenticate(String username,String password);
}
