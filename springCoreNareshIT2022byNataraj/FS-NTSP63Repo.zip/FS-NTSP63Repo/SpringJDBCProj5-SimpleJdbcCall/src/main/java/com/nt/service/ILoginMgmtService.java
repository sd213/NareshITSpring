//ILoginMgmtService .java
package com.nt.service;

public interface ILoginMgmtService {
         public   String   singnIn(String username,String password);
}
