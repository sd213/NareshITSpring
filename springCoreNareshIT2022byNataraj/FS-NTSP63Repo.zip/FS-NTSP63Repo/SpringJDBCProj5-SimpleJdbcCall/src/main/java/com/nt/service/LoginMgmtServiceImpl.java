//LoginMgmtServiceImpl.java
package com.nt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.ILoginDAO;

@Service("loginService")
public class LoginMgmtServiceImpl implements ILoginMgmtService {
	@Autowired
	private ILoginDAO  loginDAO;

	@Override
	public String singnIn(String username, String password) {
		//use DAO
		String result=loginDAO.authenticate(username, password);
		return result;
	}

}
