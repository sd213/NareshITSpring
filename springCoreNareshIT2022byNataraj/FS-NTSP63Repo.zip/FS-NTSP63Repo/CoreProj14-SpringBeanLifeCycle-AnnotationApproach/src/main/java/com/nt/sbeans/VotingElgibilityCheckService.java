//VotingElgibilityCheckService.java
package com.nt.sbeans;
 
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("voter")
public class VotingElgibilityCheckService {
	//spring bean properties
	@Value("${per.name}")
	private  String name;
	@Value("${per.age}")
	private  int age;
	@Value("${per.addrs}")
	private  String addrs;
	private  Date dov;
	
	
	
	//b.method
	public   String  checkVotingElgibility() {
		  System.out.println("VotingElgibilityCheckService.checkVotingElgibility()(B.method)");
		    if(age>=18)
		    	 return  "Mr/Miss/Mrs."+name+" u r elgible to vote  on date::"+dov;
		    else
		    	 return  "Mr/Miss/Mrs."+name+" u r not elgible to vote on date::"+dov;
		    
	}//method
	
	//Custom init method
	@PostConstruct
	public void myInit() {
		System.out.println("VotingElgibilityCheckService.myInit() (init life cyle method)");
		dov=new Date();  //initiazing the left over property
		 //  verifying whether important properties are injected properly or not
		if(name==null || age<=0)
			throw new IllegalArgumentException("Invalid inputs");
		
	}
	
	//custom destory method
	@PreDestroy
	public void myDestroy() {
		System.out.println("VotingElgibilityCheckService.myDestroy()(custom destroy() method)");
		name=null;
		addrs=null;
		age=0;
		dov=null;
	}
	
	

}//class
