//Courier.java (Common Interface)
package com.nt.sbeans;

public interface Courier {
    public   String  deliver(int oid);
}
