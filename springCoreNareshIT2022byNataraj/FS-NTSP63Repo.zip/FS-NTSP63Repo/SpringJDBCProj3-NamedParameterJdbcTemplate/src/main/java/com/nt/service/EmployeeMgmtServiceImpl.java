//EmployeeMgmtServiceImpl.java  (service Impl class)
package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.IEmployeeDAO;
import com.nt.model.Employee;

@Service("empService")
public class EmployeeMgmtServiceImpl implements IEmployeeMgmtService {
	@Autowired
	private  IEmployeeDAO  empDAO;

	@Override
	public int fetchEmpsCountBySalaryRange(float start, float end) {
		//use DAO
		int count=empDAO.getEmpsCountBySalaryRange(start, end);
		return count;
	}

	@Override
	public List<Employee> fetchEmpsByDesgs(String desg1, String desg2) {
		//use DAO
		List<Employee> list=empDAO.getEmpsByDesgs(desg1, desg2);
		return list;
		
	}
	
	@Override
	public String registerEmployee(Employee emp) {
		int count=empDAO.insertEmployee(emp);
		return count==0?"Employee not inserted":"Employee Inserted";
	}

	
}
