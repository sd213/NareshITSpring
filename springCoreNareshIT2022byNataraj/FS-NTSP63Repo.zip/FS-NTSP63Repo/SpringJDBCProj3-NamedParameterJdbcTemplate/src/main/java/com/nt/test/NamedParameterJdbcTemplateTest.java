//Client app
package com.nt.test;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.model.Employee;
import com.nt.service.IEmployeeMgmtService;

public class NamedParameterJdbcTemplateTest {

	public static void main(String[] args) {
		//create IOC container
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		//get ServiceImpl class obj
		IEmployeeMgmtService  service=ctx.getBean("empService",IEmployeeMgmtService.class);
		// invoke the b.method
		int  empsCount=service.fetchEmpsCountBySalaryRange(1000.0f, 10000.0f);
		System.out.println("Employees count ::"+empsCount);
		
		System.out.println("__________________________");
		List<Employee> list=service.fetchEmpsByDesgs("CLERK","MANAGER");
		list.forEach(emp->{
			System.out.println(emp);
		});
		
		System.out.println("__________________________");
		Employee emp=new Employee();
		emp.setEmpno(1111); emp.setEname("rajesh"); emp.setJob("CLERK"); emp.setSal(9900.0f);
		String resultMsg=service.registerEmployee(emp);
		System.out.println(resultMsg);
		
		//close contianer
		ctx.close();

	}

}
