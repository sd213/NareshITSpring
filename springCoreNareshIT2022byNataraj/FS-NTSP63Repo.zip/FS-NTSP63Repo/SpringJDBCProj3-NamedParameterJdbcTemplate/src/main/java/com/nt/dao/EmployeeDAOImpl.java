// EmployeeDAOImpl .java
package com.nt.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nt.model.Employee;

@Repository("empDAO")
public class EmployeeDAOImpl implements IEmployeeDAO{
	private  static final String  GET_EMPS_COUNT_BY_SAL_RANGE="SELECT COUNT(*) FROM EMP WHERE SAL>=:min AND SAL<=:max";
	private  static final String  GET_EMPS_BY_DESGs="SELECT EMPNO,ENAME,JOB,SAL FROM EMP WHERE JOB IN (:dsg1,:dsg2) ORDER BY JOB";
	private  static final String  INSERT_EMP_QUERY="INSERT INTO EMP (EMPNO,ENAME,JOB,SAL) VALUES (:empno,:ename,:job,:sal)";
	
	@Autowired
	private NamedParameterJdbcTemplate njt;

	@Override
	public int getEmpsCountBySalaryRange(float start, float end) {
		 // create Map object having  the names and values of named params
		  Map<String,Object>  paramsMap=new HashMap();
		  paramsMap.put("min", start);
		  paramsMap.put("max",end);
		// setting named param values using the Map object
		int count=njt.queryForObject(GET_EMPS_COUNT_BY_SAL_RANGE, paramsMap, Integer.class);  
		return count;
	}

	@Override
	public List<Employee> getEmpsByDesgs(String desg1, String desg2) {
	          // Bind values to named params  using MapSqlPArameterSource object
		   MapSqlParameterSource  source=new MapSqlParameterSource();
		   source.addValue("dsg1", desg1);
		   source.addValue("dsg2", desg2);
		  //execute the SQL Query
		   List<Employee> list=njt.query(GET_EMPS_BY_DESGs, source,
				                                              rs->{
				                                            	  //copy ResultSet obj records to List Collection
				                                            	  List<Employee> empsList=new ArrayList();
				                                            	  while(rs.next()) {
				                                            		  Employee emp=new Employee();
				                                            		  emp.setEmpno(rs.getInt(1));
				                                            		  emp.setEname(rs.getString(2));
				                                            		  emp.setJob(rs.getString(3));
				                                            		  emp.setSal(rs.getFloat(4));
				                                            		  empsList.add(emp);
				                                            	  }//while
				                                            	  return empsList;
				                                              }  );
		   
		return list;
		}

	@Override
	public int insertEmployee(Employee emp) {
		// create BeanPropertySqlParameterSource object having Model class obj name
		BeanPropertySqlParameterSource bpsps=new BeanPropertySqlParameterSource(emp);
		int count=njt.update(INSERT_EMP_QUERY, bpsps);
		return count;
	}
	
	
}
