//PerformenceMonitoringAspect.java
package com.nt.aspect;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component("pmAspect")
@Aspect
public class PerformenceMonitoringAspect {
	
	public PerformenceMonitoringAspect() {
		System.out.println("PerformenceMonitoringAspect: 0-param constructor");
	}
	
	@Around("execution(*  com.nt.service.BankService.*(..))")
	public  Object  performence(ProceedingJoinPoint pjp) throws Throwable{
		// pre logics
		long start=System.currentTimeMillis();
		System.out.println("Entering into ....target method");
		//invoke the target method
		Object retVal=pjp.proceed();
		//post logics
		long end=System.currentTimeMillis();
		System.out.println("Exited from ....target method");
		System.out.println(pjp.getSignature()+" with args"+Arrays.toString(pjp.getArgs())+" has taken "+(end-start)+" ms");
		
		return retVal;
		
	}

}
