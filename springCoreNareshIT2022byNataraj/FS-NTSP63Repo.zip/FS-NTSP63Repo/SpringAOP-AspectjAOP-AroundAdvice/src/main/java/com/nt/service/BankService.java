//BankService.java (Service class)
package com.nt.service;

import org.springframework.stereotype.Service;

@Service("bankService")
public class BankService {
	
	public BankService() {
		System.out.println("BankService:: 0-param constructor:::"+this.getClass());
	}
	
	public double  calculateSimpleIntrest(double pamt, double rate,double time ) {
		System.out.println("BankService.calculateSimpleIntrest()");
		return  (pamt*rate*time)/100.0f;
	}
	
	public double  calculatecompoundIntrest(double pamt, double rate,double time ) {
		System.out.println("BankService.calculateCompoundIntrest()");
		return    (pamt*Math.pow(1+rate/100,time))-pamt;
	}
   
   
}
