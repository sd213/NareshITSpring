//AroundAdviceTest.java
package com.nt.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.service.BankService;

public class AroundAdviceTest {
	
	public static void main(String[] args) {
		//create IOC container
		 ClassPathXmlApplicationContext ctx=
				      new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");
		 System.out.println("_----------------------------------------------------------");
			 //get Proxy class object
			 BankService proxy=ctx.getBean("bankService",BankService.class);
			 System.out.println(proxy.getClass()+"  "+proxy.getClass().getSuperclass());
			 System.out.println("_________________________________");
			 //invoke the method
			  double simpleIntrAmount=proxy.calculateSimpleIntrest(100000.0, 2.0, 12.0);
			  System.out.println("Simple Intrest amount::"+simpleIntrAmount);
			  System.out.println("___________________");
			  double compoundIntrAmount=proxy.calculatecompoundIntrest(100000.0, 2.0, 12.0);
			  System.out.println("compound Intrest amount::"+compoundIntrAmount);
			  
		 
		 
		 //close container
		 ctx.close();
	}

}
